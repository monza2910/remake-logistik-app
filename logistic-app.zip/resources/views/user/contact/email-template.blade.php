<!DOCTYPE html>
<html>
<head>
    <title>kmjtrans.com</title>
</head>
<body>
    <p>{{ $details['name'] }}</p>
    <p>{{ $details['email'] }}</p>
    <p>{{ $details['phone'] }}</p>
    <p>{{ $details['message'] }}</p>
   
    <p>Thank you</p>
</body>
</html>