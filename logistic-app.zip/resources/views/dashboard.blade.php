@extends('dashboard-admin.home')

@section('title')
    Dashboard
@endsection

@section('title-page')
    <h1>Dashboard</h1>
@endsection

@section('content')
<h1>Hiii</h1>
@endsection