<?php return array (
  'armada' => 'App\\Http\\Livewire\\Armada',
  'armadabus' => 'App\\Http\\Livewire\\Armadabus',
  'logistic' => 'App\\Http\\Livewire\\Logistic',
  'travel' => 'App\\Http\\Livewire\\Travel',
);