<!DOCTYPE html>
<html>
<head>
    <title>kmjtrans.com</title>
</head>
<body>
    <p><?php echo e($details['name']); ?></p>
    <p><?php echo e($details['email']); ?></p>
    <p><?php echo e($details['phone']); ?></p>
    <p><?php echo e($details['message']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH F:\Kerjaan\BOIS\Project\KMJTRANS\LogisticApp\resources\views/user/contact/email-template.blade.php ENDPATH**/ ?>