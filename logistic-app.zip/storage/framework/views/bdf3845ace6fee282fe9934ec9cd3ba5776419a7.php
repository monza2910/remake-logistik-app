    <!-- NAVBAR -->
    <nav id="nav" class="navbar">
        <div id="sidebar">
          <a id="openBtn"><span></span></a>
          <ul>
            <li><a id="closeBtn">X</a></li>
            <li><a href="<?php echo e(route('blog.index')); ?>" id="active">Home</a></li>
            <li><a href="<?php echo e(route('blog.showarticle')); ?>">Artikel</a></li>
            <li><a href="<?php echo e(route('blog.service')); ?>">Layanan</a></li>
            <li><a href="<?php echo e(route('blog.gallery')); ?>" >Galeri</a></li>
          </ul>
          <a href="<?php echo e(route('blog.contactus')); ?>" id="right">Contact Us</a>
          
        </div>
      </nav><?php /**PATH C:\Monza\Developer\Project\KMJ-trans\logistic-app\resources\views/blog/layout/header.blade.php ENDPATH**/ ?>