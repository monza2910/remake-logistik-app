module.exports = {
	rootDir: './tests',
};