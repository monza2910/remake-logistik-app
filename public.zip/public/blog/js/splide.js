new Splide(".splide", {
  type: "loop",
  keyboard: false,
}).mount();

new Splide(".splide.testimony", {
  type: "loop",
  autoplay: true,
  keyboard: false,
}).mount();
